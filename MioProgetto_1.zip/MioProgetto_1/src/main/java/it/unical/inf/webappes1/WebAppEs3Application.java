package it.unical.inf.webappes1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebAppEs3Application {

    public static void main(String[] args) {
        SpringApplication.run(WebAppEs3Application.class, args);
    }

}
