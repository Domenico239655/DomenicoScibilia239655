


cconsole.log('HELLO JS');

// Mostra il form per aggiungere un libro al click sul pulsante
document.getElementById("addBookButton").addEventListener("click", function() {
    document.getElementById("bookForm").style.display = "block";
    document.getElementById("removeBookForm").style.display = "none";
});

// Evento submit sul form "newBookForm"
document.getElementById("newBookForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Previene l'invio dei dati

    // Recupera i dati dai campi del form
    const title = document.getElementById("title").value.trim();
    const year = document.getElementById("year").value.trim();
    const publisher = document.getElementById("publisher").value.trim();

    // Verifica che i campi non siano vuoti
    if (title && year && publisher) {
        const tableBody = document.getElementById("bookTable").getElementsByTagName('tbody')[0];
        addNewRow(tableBody, title, year, publisher);

        // Nasconde il form e resetta i campi dopo l'inserimento
        document.getElementById("bookForm").style.display = "none";
        document.getElementById("newBookForm").reset();
    } else {
        alert("Please fill in all the fields!");
    }
});

// Funzione per aggiungere una nuova riga alla tabella
function addNewRow(tableBody, title, year, publisher) {
    const newRow = tableBody.insertRow();
    const titleCell = newRow.insertCell(0);
    const yearCell = newRow.insertCell(1);
    const publisherCell = newRow.insertCell(2);
    const deleteButtonCell = newRow.insertCell(3);

    // Popolamento delle celle
    titleCell.textContent = title;
    yearCell.innerHTML = `<span class="badge bg-primary">${year}</span>`;
    publisherCell.textContent = publisher;

    // Creazione del pulsante di eliminazione con evento click
    const deleteButton = document.createElement('button');
    deleteButton.className = 'btn btn-danger btn-sm deleteButton';
    deleteButton.innerHTML = '<i class="fa-solid fa-trash"></i>';
    deleteButton.addEventListener('click', function() {
        if (confirm('Are you sure you want to delete this book?')) {
            tableBody.removeChild(newRow);
        }
    });
    deleteButtonCell.appendChild(deleteButton);

    console.log('Adding new Row with enhanced method');
}

// Funzione opzionale per aggiungere tooltip e migliorare l'interfaccia
document.addEventListener("DOMContentLoaded", function() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.forEach(function(tooltipTriggerEl) {
        new bootstrap.Tooltip(tooltipTriggerEl);
    });
});

