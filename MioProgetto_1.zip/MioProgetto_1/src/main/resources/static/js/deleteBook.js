console.log('HELLO JS - Remove Book Functionality');

// Mostra il form per rimuovere un libro quando si clicca sul pulsante
document.getElementById("removeBookButton").addEventListener("click", function() {
    document.getElementById("removeBookForm").style.display = "block";
    document.getElementById("bookForm").style.display = "none";
});

// Aggiunge un evento submit al form di rimozione
document.getElementById("removeBookByNumberForm").addEventListener("submit", removeBookByNumber);

// Funzione per rimuovere il libro in base al numero fornito dall'utente
function removeBookByNumber(event) {
    event.preventDefault(); // Previene il comportamento predefinito del submit

    // Recupera il numero del libro da rimuovere
    const bookNumber = parseInt(document.getElementById("bookNumber").value);
    const rows = document.getElementById('bookTable').querySelectorAll('tr');

    // Controlla se il numero del libro è valido
    if (bookNumber > 0 && bookNumber < rows.length) {
        const confirmation = confirm(`Sei sicuro di voler rimuovere il libro numero ${bookNumber}?`);
        if (confirmation) {
            rows[bookNumber].remove(); // Rimuove la riga corrispondente
            alert(`Il libro numero ${bookNumber} è stato rimosso con successo.`);
        }
    } else {
        alert("Numero libro non valido! Inserisci un numero corretto.");
    }

    document.getElementById("removeBookForm").style.display = "none"; // Nasconde il form
    document.getElementById("removeBookByNumberForm").reset(); // Resetta il campo del form
}

// Aggiunge la funzionalità di eliminazione per i pulsanti "Elimina" già presenti nella tabella
const deleteButtons = document.querySelectorAll(".deleteButton");
deleteButtons.forEach(button => {
    button.addEventListener("click", function() {
        const row = button.closest("tr");
        const confirmation = confirm('Sei sicuro di voler eliminare questo libro?');
        if (confirmation) {
            row.remove(); // Rimuove la riga
            alert('Il libro è stato eliminato con successo.');
        }
    });
});

// Funzione per eliminare una riga con opzioni diverse
function deleteRow(button) {
    const row = button.closest("tr"); // Trova la riga corrente
    const confirmation = confirm('Sei sicuro di voler eliminare questa riga?');
    if (confirmation) {
        row.remove(); // Rimuove la riga
        alert('La riga è stata eliminata con successo.');
    }
}

